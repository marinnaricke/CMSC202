#ifndef HELLO_UTIL_H
#define HELLO_UTIL_H

#include <string>

// function prototypes

void hello( );
void hello( std::string message );

#endif
