#include <iostream>
#include "hello_util.h"

using namespace std;

int main() {

  hello();
  
  cout << endl;

  hello( "The semester is almost over!!" );

  return 0;
}
