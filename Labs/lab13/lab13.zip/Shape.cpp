#include "Shape.h"
#include <iostream>
using namespace std;

void Shape::draw() const
{
  cout << "Drawing a shape..." << endl;
}
